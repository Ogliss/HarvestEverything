﻿using System;
using Verse;

namespace Harvest_Everything
{
	// Token: 0x02000002 RID: 2
	[StaticConstructorOnStartup]
	public static class HarvestEverything
	{
	}
}
