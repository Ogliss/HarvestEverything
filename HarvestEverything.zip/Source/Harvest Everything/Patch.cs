﻿using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Harvest_Everything
{
	// Token: 0x02000004 RID: 4
	[StaticConstructorOnStartup]
	class Patch
	{
		// Token: 0x06000003 RID: 3 RVA: 0x0000205C File Offset: 0x0000025C
		static Patch()
		{
			Harmony harmonyInstance = new Harmony("com.github.ianjazz246.harvest_everything");
            MethodInfo method = AccessTools.TypeByName("RimWorld.Recipe_RemoveBodyPart").GetMethod("GetPartsToApplyOn");
            MethodInfo method2 = typeof(Patch).GetMethod("GetPartsPostfix", BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.FlattenHierarchy);
            bool flag = method2 == null;
            if (flag)
            {
                Log.Error("Postfix is null", false);
            }
            bool flag2 = harmonyInstance.Patch(method, null, new HarmonyMethod(method2)) == null;
            if (flag2)
            {
                Log.Error("Harvest Everything Harmony patch failed.", false);
            }
            harmonyInstance.PatchAll(Assembly.GetExecutingAssembly());
        }

		// Token: 0x06000004 RID: 4 RVA: 0x000020EE File Offset: 0x000002EE
		private static IEnumerable<BodyPartRecord> GetAllChildParts(BodyPartRecord part)
		{
			yield return part;
			foreach (BodyPartRecord child in part.parts)
			{
				foreach (BodyPartRecord subChild in Patch.GetAllChildParts(child))
				{
					yield return subChild;
	
				}
			}
			yield break;
		}

		// Token: 0x06000005 RID: 5 RVA: 0x00002100 File Offset: 0x00000300
		private static bool IsChildrenClean(Pawn pawn, BodyPartRecord part)
		{
			IEnumerable<BodyPartRecord> allChildParts = Patch.GetAllChildParts(part);
			foreach (BodyPartRecord bodyPartRecord in allChildParts)
			{
				bool flag = !MedicalRecipesUtility.IsClean(pawn, bodyPartRecord);
				if (flag)
				{
					return false;
				}
			}
			return true;
		}

		// Token: 0x06000006 RID: 6 RVA: 0x00002168 File Offset: 0x00000368
		private static IEnumerable<BodyPartRecord> GetPartsPostfix(IEnumerable<BodyPartRecord> __result, Pawn pawn)
		{
			foreach (BodyPartRecord part in __result)
			{
				bool flag = part.def.HasModExtension<ModExtension>() && part.def.GetModExtension<ModExtension>().requireCleanChildrenToRemove;
				if (flag)
				{
					bool flag2 = !Patch.IsChildrenClean(pawn, part);
					if (flag2)
					{
						continue;
					}
				}
				yield return part;
			}
			yield break;
		}

		// Token: 0x06000007 RID: 7 RVA: 0x0000217F File Offset: 0x0000037F
		private static void ApplyOnPawnPostfix(Pawn pawn, BodyPartRecord part, List<Thing> ingredients)
		{
		}
	}
}
