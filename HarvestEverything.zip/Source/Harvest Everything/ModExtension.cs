﻿using System;
using Verse;

namespace Harvest_Everything
{
	// Token: 0x02000003 RID: 3
	public class ModExtension : DefModExtension
	{
		// Token: 0x04000001 RID: 1
		public bool requireCleanChildrenToRemove;
	}
}
